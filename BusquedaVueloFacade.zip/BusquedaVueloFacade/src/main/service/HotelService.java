package main.service;

import main.model.BusquedaHotel;
import main.model.BusquedaVuelo;

public class HotelService {

    public String obtenerHotel(BusquedaHotel busquedaHotel){
        return "Si hay un hotel disponible en esta fecha";
    }

}
