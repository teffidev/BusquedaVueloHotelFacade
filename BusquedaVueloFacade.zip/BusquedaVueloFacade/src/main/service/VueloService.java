package main.service;

import main.model.BusquedaVuelo;

public class VueloService {

    public String obtenerVuelo(BusquedaVuelo busquedaVuelo){
        return "Si hay un vuelo para tu fecha";
    }

}
